<?php

include '../config/database.php';

$course_code =
$_POST['course_code'];

$course_title =
$_POST['course_title'];

$department =
$_POST['department'];

$attendance_target =
$_POST['attendance_target'];

$sql = "INSERT INTO courses
(
course_code,
course_title,
department,
attendance_target
)
VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([

    $course_code,

    $course_title,

    $department,

    $attendance_target

]);

echo "Course Added";

?>