<?php

include '../config/database.php';

$lecturer_id =
$_POST['lecturer_id'];

$course_id =
$_POST['course_id'];

$venue_id =
$_POST['venue_id'];

$sql = "INSERT INTO lecturer_courses
(
lecturer_id,
course_id,
venue_id
)
VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([

    $lecturer_id,

    $course_id,

    $venue_id

]);

echo "Course Assigned";

?>