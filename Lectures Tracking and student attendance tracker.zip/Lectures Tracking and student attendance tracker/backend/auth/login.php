<?php

session_start();

include '../config/database.php';

$email =
$_POST['email'];

$password =
$_POST['password'];

$user_type =
$_POST['user_type'];

if($user_type == "admin"){

    $table = "admins";

}elseif($user_type == "lecturer"){

    $table = "lecturers";

}else{

    echo json_encode([

        "status" => "error",

        "message" =>
        "Students login from school portal"

    ]);

    exit();

}

$sql = "SELECT * FROM $table
WHERE email = ?";

$stmt = $conn->prepare($sql);

$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(
    $user &&
    password_verify(
        $password,
        $user['password']
    )
){

    $_SESSION['user_id'] =
    $user['id'];

    $_SESSION['user_type'] =
    $user_type;

    echo json_encode([

        "status" => "success",

        "user" => $user

    ]);

}else{

    echo json_encode([

        "status" => "error",

        "message" =>
        "Invalid Login"

    ]);

}

?>