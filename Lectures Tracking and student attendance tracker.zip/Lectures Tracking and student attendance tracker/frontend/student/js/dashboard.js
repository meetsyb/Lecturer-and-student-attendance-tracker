/* student.js */

/* THEME */

const toggleBtn =
document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme","dark");

        toggleBtn.innerHTML = "☀️";

    }else{

        localStorage.setItem("theme","light");

        toggleBtn.innerHTML = "🌙";

    }

});

/* LOAD THEME */

window.onload = () => {

    const savedTheme =
    localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add("dark-mode");

        toggleBtn.innerHTML = "☀️";

    }

};

/* SIDEBAR */

const menuBtn =
document.getElementById("menuBtn");

const sidebar =
document.getElementById("sidebar");

menuBtn.addEventListener("click", (e) => {

    e.stopPropagation();

    sidebar.classList.toggle("active");

});

/* CLOSE SIDEBAR */

document.addEventListener("click", (e) => {

    if(
        !sidebar.contains(e.target) &&
        !menuBtn.contains(e.target)
    ){

        sidebar.classList.remove("active");

    }

});

/* ATTENDANCE CODE */

const submitCodeBtn =
document.getElementById("submitCodeBtn");

const attendanceCode =
document.getElementById("attendanceCode");

const statusMessage =
document.getElementById("statusMessage");

submitCodeBtn.addEventListener("click", () => {

    const code =
    attendanceCode.value.trim();

    if(code === ""){

        statusMessage.innerHTML =
        "Please enter attendance code.";

        statusMessage.style.color =
        "red";

        return;
    }

    /* DEMO CODE */

    if(code === "PLA-5821"){

        statusMessage.innerHTML =
        "Attendance Verified Successfully.";

        statusMessage.style.color =
        "green";

    }else{

        statusMessage.innerHTML =
        "Invalid Attendance Code.";

        statusMessage.style.color =
        "red";

    }

});

/* LOGOUT */

const logoutBtn =
document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", () => {

    localStorage.removeItem(
        "studentLoggedIn"
    );

    window.location.href =
    "../student-login.html";

});