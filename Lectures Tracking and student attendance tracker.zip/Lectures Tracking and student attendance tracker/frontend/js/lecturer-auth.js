const lecturerEmail = "noelsule8@gmail.com";

const lecturerPassword = "12345";

const form = document.getElementById("lecturerLoginForm");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email =
    document.getElementById("email").value;

    const password =
    document.getElementById("password").value;

    if(email === lecturerEmail &&
       password === lecturerPassword){

        localStorage.setItem(
            "lecturerLoggedIn",
            "true"
        );

        window.location.href =
        "lecturer-dashboard.html";

    }else{

        alert("Invalid Login Details");

    }

});