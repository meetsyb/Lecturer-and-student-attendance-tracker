<?php

include '../config/database.php';

$venue_name =
$_POST['venue_name'];

$latitude =
$_POST['latitude'];

$longitude =
$_POST['longitude'];

$sql = "INSERT INTO venues
(
venue_name,
latitude,
longitude
)
VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([

    $venue_name,

    $latitude,

    $longitude

]);

echo "Venue Added";

?>