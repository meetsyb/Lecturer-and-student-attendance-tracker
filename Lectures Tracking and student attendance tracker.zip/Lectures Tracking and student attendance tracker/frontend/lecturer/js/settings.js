/* ========================= */
/* THEME TOGGLE */
/* ========================= */

const toggleBtn =
document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme","dark");

        toggleBtn.innerHTML = "☀️ Toggle Theme";

    }else{

        localStorage.setItem("theme","light");

        toggleBtn.innerHTML = "🌙 Toggle Theme";

    }

});

/* LOAD THEME */

window.onload = () => {

    const savedTheme =
    localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add("dark-mode");

        toggleBtn.innerHTML = "☀️ Toggle Theme";

    }

};

/* ========================= */
/* MOBILE SIDEBAR */
/* ========================= */

const menuBtn =
document.getElementById("menuBtn");

const sidebar =
document.getElementById("sidebar");

menuBtn.addEventListener("click", (e) => {

    e.stopPropagation();

    sidebar.classList.toggle("active");

});

/* CLOSE SIDEBAR */

document.addEventListener("click", (e) => {

    if(
        !sidebar.contains(e.target) &&
        !menuBtn.contains(e.target)
    ){

        sidebar.classList.remove("active");

    }

});

/* ========================= */
/* LOGOUT */
/* ========================= */

const logoutBtn =
document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", () => {

    localStorage.removeItem(
        "lecturerLoggedIn"
    );

    window.location.href =
    "../lecturer-login.html";

});