<?php

include '../config/database.php';

$lecturer_id =
$_POST['lecturer_id'];

$course_id =
$_POST['course_id'];

$venue_id =
$_POST['venue_id'];

$otp =
"PLA-" . rand(1000,9999);

$qr_token =
md5(uniqid());

$start_time =
date('Y-m-d H:i:s');

$expires_at =
date(
'Y-m-d H:i:s',
strtotime('+5 minutes')
);

$sql = "INSERT INTO lecture_sessions
(
lecturer_id,
course_id,
venue_id,
otp_code,
qr_token,
start_time,
expires_at
)
VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([

    $lecturer_id,

    $course_id,

    $venue_id,

    $otp,

    $qr_token,

    $start_time,

    $expires_at

]);

echo json_encode([

    "status" => "success",

    "otp" => $otp,

    "qr_token" => $qr_token,

    "expires_at" => $expires_at

]);

?>