const toggleBtn = document.getElementById("themeToggle");

/* TOGGLE THEME */

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme", "dark");

        toggleBtn.innerHTML = "☀️";

    }else{

        localStorage.setItem("theme", "light");

        toggleBtn.innerHTML = "🌙";

    }

});

/* LOAD SAVED THEME */

window.onload = () => {

    const savedTheme = localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add("dark-mode");

        toggleBtn.innerHTML = "☀️";
    }

};

/* ========================= */
/* DARK / LIGHT MODE */
/* ========================= */

const toggleBtn =
document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle(
        "dark-mode"
    );

    if(document.body.classList.contains(
        "dark-mode"
    )){

        localStorage.setItem(
            "theme",
            "dark"
        );

        toggleBtn.innerHTML = "☀️";

    }else{

        localStorage.setItem(
            "theme",
            "light"
        );

        toggleBtn.innerHTML = "🌙";

    }

});

/* LOAD SAVED THEME */

window.onload = () => {

    const savedTheme =
    localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add(
            "dark-mode"
        );

        toggleBtn.innerHTML = "☀️";

    }

};