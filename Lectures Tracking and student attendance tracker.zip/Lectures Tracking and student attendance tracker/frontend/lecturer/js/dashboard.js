/* ========================= */
/* THEME TOGGLE */
/* ========================= */

const toggleBtn =
document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme", "dark");

        toggleBtn.innerHTML = "☀️";

    }else{

        localStorage.setItem("theme", "light");

        toggleBtn.innerHTML = "🌙";

    }

});

/* LOAD SAVED THEME */

window.onload = () => {

    const savedTheme =
    localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add("dark-mode");

        toggleBtn.innerHTML = "☀️";

    }

};

/* ========================= */
/* MOBILE SIDEBAR */
/* ========================= */

const menuBtn =
document.getElementById("menuBtn");

const sidebar =
document.getElementById("sidebar");

/* OPEN/CLOSE SIDEBAR */

menuBtn.addEventListener("click", (e) => {

    e.stopPropagation();

    sidebar.classList.toggle("active");

});

/* CLOSE WHEN CLICKING OUTSIDE */

document.addEventListener("click", (e) => {

    if(
        !sidebar.contains(e.target) &&
        !menuBtn.contains(e.target)
    ){

        sidebar.classList.remove("active");

    }

});

/* CLOSE WHEN CLICKING MENU ITEM */

const menuItems =
document.querySelectorAll(".menu li");

menuItems.forEach((item) => {

    item.addEventListener("click", () => {

        sidebar.classList.remove("active");

    });

});

/* ========================= */
/* LOGOUT */
/* ========================= */

const logoutBtn =
document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", () => {

    localStorage.removeItem(
        "lecturerLoggedIn"
    );

    window.location.href =
    "lecturer-login.html";

});

/* ========================= */
/* QR GENERATOR */
/* ========================= */

const qrBtn =
document.getElementById("generateQR");

const qrContainer =
document.getElementById("qrcode");

const countdown =
document.getElementById("countdown");

let timer;

/* GENERATE QR */

qrBtn.addEventListener("click", () => {

    /* CLEAR OLD QR */

    qrContainer.innerHTML = "";

    /* GENERATE SESSION ID */

    const sessionId =
    "PLASU-" +
    Math.floor(Math.random() * 999999);

    /* GENERATE QR */

    new QRCode(qrContainer, {

        text: sessionId,

        width:220,

        height:220,

    });

    /* RESET TIMER */

    clearInterval(timer);

    let timeLeft = 300;

    timer = setInterval(() => {

        let minutes =
        Math.floor(timeLeft / 60);

        let seconds =
        timeLeft % 60;

        seconds =
        seconds < 10
        ? "0" + seconds
        : seconds;

        countdown.innerHTML =
        `${minutes}:${seconds}`;

        /* EXPIRE */

        if(timeLeft <= 0){

            clearInterval(timer);

            countdown.innerHTML =
            "Expired";

            qrContainer.innerHTML =
            "<h3>QR Expired</h3>";

        }

        timeLeft--;

    },1000);

});

/* SAVE LOGIN SESSION */

localStorage.setItem(
    "lecturerLoggedIn",
    "true"
);

/* REDIRECT */

window.location.href =
"lecturer/lecturer-dashboard.html";

/* ========================= */
/* AUTH GUARD */
/* ========================= */

if(
    localStorage.getItem(
        "lecturerLoggedIn"
    ) !== "true"
){

    window.location.href =
    "../lecturer-login.html";

}



