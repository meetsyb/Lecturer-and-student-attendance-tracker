/* ========================= */
/* STUDENT LOGIN */
/* ========================= */

document.addEventListener(
"DOMContentLoaded",()=>{

    const form =
    document.getElementById(
        "studentLoginForm"
    );

    if(form){

        form.addEventListener(
        "submit",(e)=>{

            e.preventDefault();

            /* INPUTS */

            const email =
            document.getElementById(
                "email"
            ).value.trim();

            const password =
            document.getElementById(
                "password"
            ).value.trim();

            /* LOGIN DETAILS */

            const defaultEmail =
            "noelsule8@gmail.com";

            const defaultPassword =
            "12345";

            /* VALIDATION */

            if(
                email === defaultEmail &&
                password === defaultPassword
            ){

                /* SAVE LOGIN */

                localStorage.setItem(
                    "studentLoggedIn",
                    "true"
                );

                /* REDIRECT */

                window.location.replace(
                    "student-dashboard.html"
                );

            }else{

                alert(
                    "Invalid Email or Password"
                );

            }

        });

    }

});