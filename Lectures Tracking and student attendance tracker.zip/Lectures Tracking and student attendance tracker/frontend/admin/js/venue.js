console.log("Venue JS Connected");

/* ========================= */
/* WAIT FOR DOM */
/* ========================= */

document.addEventListener(
"DOMContentLoaded",
function(){

    /* ========================= */
    /* ELEMENTS */
    /* ========================= */

    const menuBtn =
    document.getElementById(
        "menuBtn"
    );

    const sidebar =
    document.getElementById(
        "sidebar"
    );

    const themeToggle =
    document.getElementById(
        "themeToggle"
    );

    /* ========================= */
    /* MOBILE SIDEBAR */
    /* ========================= */

    menuBtn.addEventListener(
    "click",
    function(e){

        e.stopPropagation();

        sidebar.classList.toggle(
            "active"
        );

    });

    /* CLOSE SIDEBAR */

    document.addEventListener(
    "click",
    function(e){

        if(
            !sidebar.contains(e.target)
            &&
            !menuBtn.contains(e.target)
        ){

            sidebar.classList.remove(
                "active"
            );

        }

    });

    /* ========================= */
    /* THEME TOGGLE */
    /* ========================= */

    themeToggle.addEventListener(
    "click",
    function(){

        document.body.classList.toggle(
            "dark-mode"
        );

        /* SAVE THEME */

        if(
            document.body.classList.contains(
                "dark-mode"
            )
        ){

            localStorage.setItem(
                "theme",
                "dark"
            );

            themeToggle.innerHTML =
            "☀️";

        }else{

            localStorage.setItem(
                "theme",
                "light"
            );

            themeToggle.innerHTML =
            "🌙";

        }

    });

    /* LOAD SAVED THEME */

    const savedTheme =
    localStorage.getItem(
        "theme"
    );

    if(savedTheme === "dark"){

        document.body.classList.add(
            "dark-mode"
        );

        themeToggle.innerHTML =
        "☀️";

    }

    /* ========================= */
    /* MAP */
    /* ========================= */

    const map = L.map('map').setView(
        [9.0579, 7.4951],
        13
    );

    /* TILE */

    L.tileLayer(
    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    {
        attribution:'© OpenStreetMap'
    }).addTo(map);

    /* MARKER */

    let marker;

    /* MAP CLICK */

    map.on('click', function(e){

        const lat = e.latlng.lat;

        const lng = e.latlng.lng;

        /* REMOVE OLD */

        if(marker){

            map.removeLayer(marker);

        }

        /* NEW MARKER */

        marker = L.marker([lat,lng])
        .addTo(map);

        /* INPUT VALUES */

        document.getElementById(
            "latitude"
        ).value = lat;

        document.getElementById(
            "longitude"
        ).value = lng;

    });

    /* ========================= */
    /* SAVE VENUE */
    /* ========================= */

    const venueForm =
    document.getElementById(
        "venueForm"
    );

    venueForm.addEventListener(
    "submit",
    function(e){

        e.preventDefault();

        /* CREATE OBJECT */

        const venue = {

            name:
            document.getElementById(
                "venueName"
            ).value,

            faculty:
            document.getElementById(
                "venueFaculty"
            ).value,

            radius:
            document.getElementById(
                "venueRadius"
            ).value,

            latitude:
            document.getElementById(
                "latitude"
            ).value,

            longitude:
            document.getElementById(
                "longitude"
            ).value

        };

        /* GET EXISTING */

        let venues =
        JSON.parse(
            localStorage.getItem(
                "venues"
            )
        ) || [];

        /* PUSH */

        venues.push(venue);

        /* SAVE */

        localStorage.setItem(
            "venues",
            JSON.stringify(venues)
        );

        /* RELOAD TABLE */

        loadVenues();

        /* RESET */

        venueForm.reset();

        alert(
            "Venue Saved Successfully"
        );

    });

    /* ========================= */
    /* LOAD TABLE */
    /* ========================= */

    function loadVenues(){

        const table =
        document.getElementById(
            "venueTableBody"
        );

        table.innerHTML = "";

        const venues =
        JSON.parse(
            localStorage.getItem(
                "venues"
            )
        ) || [];

        venues.forEach((venue)=>{

            table.innerHTML += `

            <tr>

                <td>${venue.name}</td>

                <td>${venue.faculty}</td>

                <td>${venue.radius}m</td>

                <td>${venue.latitude}</td>

                <td>${venue.longitude}</td>

            </tr>

            `;

        });

    }

    /* INITIAL LOAD */

    loadVenues();

});