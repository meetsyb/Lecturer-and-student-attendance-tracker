/* attendance.js */

/* MENU */

const menuBtn =
document.getElementById("menuBtn");

const sidebar =
document.getElementById("sidebar");

menuBtn.addEventListener("click", () => {

    sidebar.classList.toggle("active");

});

/* CLOSE SIDEBAR */

document.addEventListener("click", (e) => {

    if(
        !sidebar.contains(e.target) &&
        !menuBtn.contains(e.target)
    ){

        sidebar.classList.remove("active");

    }

});

/* THEME */

const themeToggle =
document.getElementById("themeToggle");

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

});

/* VERIFY OTP */

const verifyBtn =
document.getElementById("verifyBtn");

const attendanceCode =
document.getElementById("attendanceCode");

const statusMessage =
document.getElementById("statusMessage");

verifyBtn.addEventListener("click", () => {

    const code =
    attendanceCode.value.trim();

    if(code === ""){

        statusMessage.innerHTML =
        "Please enter OTP code.";

        statusMessage.className =
        "status-message error";

        return;
    }

    /* DEMO OTP */

    if(code === "PLA-5821"){

        statusMessage.innerHTML =
        "Attendance Verified Successfully.";

        statusMessage.className =
        "status-message success";

    }else{

        statusMessage.innerHTML =
        "Invalid or Expired OTP.";

        statusMessage.className =
        "status-message error";

    }

});

/* QR BUTTON */

const scanQRBtn =
document.getElementById("scanQRBtn");

scanQRBtn.addEventListener("click", () => {

    alert(
        "QR Scanner will be connected later."
    );

});

/* LOGOUT */

const logoutBtn =
document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", () => {

    window.location.href =
    "../index.html";

});