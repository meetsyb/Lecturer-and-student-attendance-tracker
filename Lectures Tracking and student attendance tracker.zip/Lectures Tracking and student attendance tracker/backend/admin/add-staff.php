<?php

include '../config/database.php';

$fullname =
$_POST['fullname'];

$email =
$_POST['email'];

$department =
$_POST['department'];

$password = password_hash(

    $_POST['password'],

    PASSWORD_DEFAULT

);

$sql = "INSERT INTO lecturers
(
fullname,
email,
department,
password
)
VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([

    $fullname,

    $email,

    $department,

    $password

]);

echo "Lecturer Added";

?>