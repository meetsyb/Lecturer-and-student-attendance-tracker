function toggleMode() {
  const mode = document.getElementById("mode").value;
  document.getElementById("meetLink").style.display = mode === "online" ? "block" : "none";
  document.getElementById("venue").style.display = mode === "physical" ? "block" : "none";
}

function addLecture() {
  const lecture = {
    course: course.value,
    lecturer: lecturer.value,
    date: date.value,
    time: time.value,
    endTime: endTime.value,
    mode: mode.value,
    meetLink: meetLink.value,
    venue: venue.value,
    status: "scheduled",
    startedAt: null
  };

  let lectures = JSON.parse(localStorage.getItem("lectures")) || [];
  lectures.push(lecture);

  localStorage.setItem("lectures", JSON.stringify(lectures));
  loadLectures();
}

function loadLectures() {
  let lectures = JSON.parse(localStorage.getItem("lectures")) || [];
  let attendance = JSON.parse(localStorage.getItem("attendance")) || [];
  const table = document.getElementById("lectureTable");

  table.innerHTML = `
    <tr>
      <th>Course</th>
      <th>Lecturer</th>
      <th>Date</th>
      <th>Start</th>
      <th>End</th>
      <th>Status</th>
      <th>Students</th>
      <th>Action</th>
    </tr>
  `;

  lectures.forEach((l, index) => {

    const now = new Date();
    const startTime = new Date(l.date + " " + l.time);
    const endTime = new Date(l.date + " " + l.endTime);

    // AUTO STATUS
    if (now >= startTime && now <= endTime && l.status === "scheduled") {
      l.status = "live";
      localStorage.setItem("activeLecture", index);
    }

    if (now > startTime && now <= endTime && !l.startedAt) {
      l.status = "late";
    }

    if (now > endTime && !l.startedAt) {
      l.status = "missed";
    }

    if (l.startedAt && now > endTime) {
      l.status = "completed";
    }

    const count = attendance.filter(a => a.lectureIndex == index).length;

    const row = table.insertRow();

    row.insertCell(0).innerText = l.course;
    row.insertCell(1).innerText = l.lecturer;
    row.insertCell(2).innerText = l.date;
    row.insertCell(3).innerText = l.time;
    row.insertCell(4).innerText = l.endTime;

    let status = l.status;
    if (status === "live") status = "LIVE 🟢";
    if (status === "late") status = "LATE ⚠️";
    if (status === "missed") status = "MISSED ❌";
    if (status === "completed") status = "COMPLETED ✔";

    row.insertCell(5).innerText = status;
    row.insertCell(6).innerText = count;

    let action = `<button onclick="startClass(${index})">Start</button>`;
    if (l.mode === "online") {
      action += `<button onclick="joinMeet('${l.meetLink}')">Join</button>`;
    } else {
      action += ` (${l.venue})`;
    }

    row.insertCell(7).innerHTML = action;
  });

  localStorage.setItem("lectures", JSON.stringify(lectures));
}

function startClass(index) {
  let lectures = JSON.parse(localStorage.getItem("lectures")) || [];

  lectures[index].startedAt = new Date().toISOString();
  lectures[index].status = "live";

  localStorage.setItem("activeLecture", index);
  localStorage.setItem("lectures", JSON.stringify(lectures));

  loadLectures();
}

function joinMeet(link) {
  window.open(link, "_blank");
}

loadLectures();
