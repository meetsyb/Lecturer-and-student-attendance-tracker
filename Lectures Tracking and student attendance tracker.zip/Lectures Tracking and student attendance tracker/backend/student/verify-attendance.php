<?php

include '../config/database.php';

/*
Student comes from
school portal database
*/

$student_id =
$_POST['student_id'];

$otp_code =
$_POST['otp_code'];

$sql = "SELECT * FROM lecture_sessions
WHERE otp_code = ?
AND status = 'active'
AND expires_at > NOW()";

$stmt = $conn->prepare($sql);

$stmt->execute([$otp_code]);

$session =
$stmt->fetch(PDO::FETCH_ASSOC);

if(!$session){

    echo json_encode([

        "status" => "error",

        "message" =>
        "Invalid or Expired OTP"

    ]);

    exit();

}

$course_id =
$session['course_id'];

/*
Check student registered course
from school portal database
*/

$checkCourse = "
SELECT * FROM registered_courses
WHERE student_id = ?
AND course_id = ?
";

$courseStmt =
$conn->prepare($checkCourse);

$courseStmt->execute([

    $student_id,

    $course_id

]);

if($courseStmt->rowCount() == 0){

    echo json_encode([

        "status" => "error",

        "message" =>
        "Course Not Registered"

    ]);

    exit();

}

/*
Prevent duplicate attendance
*/

$checkAttendance = "
SELECT * FROM attendance
WHERE student_id = ?
AND session_id = ?
";

$attendanceStmt =
$conn->prepare($checkAttendance);

$attendanceStmt->execute([

    $student_id,

    $session['id']

]);

if($attendanceStmt->rowCount() > 0){

    echo json_encode([

        "status" => "error",

        "message" =>
        "Attendance Already Marked"

    ]);

    exit();

}

/*
Insert attendance
*/

$insert = "
INSERT INTO attendance
(
student_id,
session_id
)
VALUES (?, ?)
";

$insertStmt =
$conn->prepare($insert);

$insertStmt->execute([

    $student_id,

    $session['id']

]);

echo json_encode([

    "status" => "success",

    "message" =>
    "Attendance Verified"

]);

?>