const defaultEmail = "noelsule8@gmail.com";

const defaultPassword = "12345";

const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(e){

    e.preventDefault();

    const email = document.getElementById("email").value;

    const password = document.getElementById("password").value;

    if(email === defaultEmail &&
       password === defaultPassword){

        localStorage.setItem(
            "plasu_token",
            "logged_in"
        );

        window.location.href = "dashboard.html";

    }else{

        alert("Invalid Login Details");

    }

});