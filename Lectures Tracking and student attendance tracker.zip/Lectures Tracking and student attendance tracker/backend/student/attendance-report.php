<?php

include '../config/database.php';

$student_id =
$_GET['student_id'];

$sql = "
SELECT COUNT(*) AS total_attendance
FROM attendance
WHERE student_id = ?
";

$stmt = $conn->prepare($sql);

$stmt->execute([$student_id]);

$result =
$stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($result);

?>