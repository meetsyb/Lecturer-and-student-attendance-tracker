document.addEventListener("DOMContentLoaded", function () {

  const users = [
    {
      email: "noelsule8@gmail.com",
      password: "12345",
      role: "admin"
    }
  ];

  const form = document.getElementById("loginForm");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
      window.location.href = "index.html";
    } else {
      document.getElementById("error").innerText = "Invalid email or password";
    }
  });

});