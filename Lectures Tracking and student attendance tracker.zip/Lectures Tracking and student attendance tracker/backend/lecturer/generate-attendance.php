<?php

include '../config/database.php';

$lecturer_id = 1;
$course_id = 1;
$venue_id = 1;

$otp =
"PLA-" . rand(1000,9999);

$start_time =
date('Y-m-d H:i:s');

$expires_at =
date(
'Y-m-d H:i:s',
strtotime('+5 minutes')
);

$sql = "INSERT INTO lecture_sessions
(
lecturer_id,
course_id,
venue_id,
otp_code,
start_time,
expires_at
)
VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->execute([
    $lecturer_id,
    $course_id,
    $venue_id,
    $otp,
    $start_time,
    $expires_at
]);

echo json_encode([

    "status" => "success",

    "otp_code" => $otp,

    "expires_at" => $expires_at

]);

?>