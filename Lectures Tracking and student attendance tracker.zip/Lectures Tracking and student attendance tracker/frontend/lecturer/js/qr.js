/* ========================= */
/* THEME TOGGLE */
/* ========================= */

const toggleBtn =
document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme","dark");

        toggleBtn.innerHTML = "☀️";

    }else{

        localStorage.setItem("theme","light");

        toggleBtn.innerHTML = "🌙";

    }

});

/* LOAD THEME */

window.onload = () => {

    const savedTheme =
    localStorage.getItem("theme");

    if(savedTheme === "dark"){

        document.body.classList.add("dark-mode");

        toggleBtn.innerHTML = "☀️";

    }

};

/* ========================= */
/* SIDEBAR */
/* ========================= */

const menuBtn =
document.getElementById("menuBtn");

const sidebar =
document.getElementById("sidebar");

menuBtn.addEventListener("click", (e) => {

    e.stopPropagation();

    sidebar.classList.toggle("active");

});

/* CLOSE SIDEBAR */

document.addEventListener("click", (e) => {

    if(
        !sidebar.contains(e.target) &&
        !menuBtn.contains(e.target)
    ){

        sidebar.classList.remove("active");

    }

});

/* ========================= */
/* QR + OTP SYSTEM */
/* ========================= */

const qrSection =
document.getElementById("qrSection");

const otpSection =
document.getElementById("otpSection");

const otpCode =
document.getElementById("otpCode");

const radios =
document.querySelectorAll(
'input[name="attendanceMethod"]'
);

/* CHANGE METHOD */

radios.forEach((radio) => {

    radio.addEventListener("change", () => {

        const method = radio.value;

        /* QR ONLY */

        if(method === "qr"){

            qrSection.style.display = "block";

            otpSection.style.display = "none";

        }

        /* OTP ONLY */

        else if(method === "otp"){

            qrSection.style.display = "none";

            otpSection.style.display = "block";

            generateOTP();

        }

        /* BOTH */

        else{

            qrSection.style.display = "block";

            otpSection.style.display = "block";

            generateOTP();

        }

    });

});

/* ========================= */
/* OTP GENERATOR */
/* ========================= */

function generateOTP(){

    const otp = Math.floor(
        100000 + Math.random() * 900000
    );

    otpCode.innerHTML = otp;
}

/* ========================= */
/* QR GENERATOR */
/* ========================= */

const qrContainer =
document.getElementById("qrcode");

/* GENERATE QR */

new QRCode(qrContainer, {

    text:"PLASU Attendance Session",

    width:220,

    height:220

});

/* ========================= */
/* COUNTDOWN TIMER */
/* ========================= */

let duration = 300;

const countdown =
document.getElementById("countdown");

const timer = setInterval(() => {

    const minutes =
    Math.floor(duration / 60);

    const seconds =
    duration % 60;

    countdown.innerHTML =

    `${minutes}:${
        seconds < 10 ? "0" : ""
    }${seconds}`;

    duration--;

    if(duration < 0){

        clearInterval(timer);

        countdown.innerHTML =
        "Expired";

    }

},1000);

/* ========================= */
/* START LECTURE */
/* ========================= */

const startLecture =
document.getElementById("startLecture");

startLecture.addEventListener("click", () => {

    alert(
        "Lecture Started Successfully"
    );

});

/* ========================= */
/* END LECTURE */
/* ========================= */

const endLecture =
document.getElementById("endLecture");

endLecture.addEventListener("click", () => {

    alert(
        "Lecture Ended"
    );

});

/* ========================= */
/* LOGOUT */
/* ========================= */

const logoutBtn =
document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", () => {

    localStorage.removeItem(
        "lecturerLoggedIn"
    );

    window.location.href =
    "../lecturer-login.html";

});