CREATE DATABASE plasu_attendance_tracker;

USE plasu_attendance_tracker;

-- ADMINS

CREATE TABLE admins (

    id INT AUTO_INCREMENT PRIMARY KEY,

    fullname VARCHAR(100),

    email VARCHAR(100) UNIQUE,

    password VARCHAR(255),

    created_at TIMESTAMP
    DEFAULT CURRENT_TIMESTAMP

);

-- LECTURERS

CREATE TABLE lecturers (

    id INT AUTO_INCREMENT PRIMARY KEY,

    fullname VARCHAR(100),

    email VARCHAR(100) UNIQUE,

    department VARCHAR(100),

    password VARCHAR(255),

    created_at TIMESTAMP
    DEFAULT CURRENT_TIMESTAMP

);

-- COURSES

CREATE TABLE courses (

    id INT AUTO_INCREMENT PRIMARY KEY,

    course_code VARCHAR(20),

    course_title VARCHAR(150),

    department VARCHAR(100),

    attendance_target INT DEFAULT 15

);

-- VENUES

CREATE TABLE venues (

    id INT AUTO_INCREMENT PRIMARY KEY,

    venue_name VARCHAR(100),

    latitude VARCHAR(100),

    longitude VARCHAR(100)

);

-- COURSE ASSIGNMENT

CREATE TABLE lecturer_courses (

    id INT AUTO_INCREMENT PRIMARY KEY,

    lecturer_id INT,

    course_id INT,

    venue_id INT

);

-- LECTURE SESSIONS

CREATE TABLE lecture_sessions (

    id INT AUTO_INCREMENT PRIMARY KEY,

    lecturer_id INT,

    course_id INT,

    venue_id INT,

    otp_code VARCHAR(20),

    qr_token TEXT,

    start_time DATETIME,

    expires_at DATETIME,

    status VARCHAR(20)
    DEFAULT 'active'

);

-- ATTENDANCE

CREATE TABLE attendance (

    id INT AUTO_INCREMENT PRIMARY KEY,

    student_id INT,

    session_id INT,

    attendance_time DATETIME
    DEFAULT CURRENT_TIMESTAMP,

    status VARCHAR(20)
    DEFAULT 'present'

);